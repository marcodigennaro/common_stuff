# common_stuff

This package contains a set of common functions to be deployed in data analysis and materials informatics projects.